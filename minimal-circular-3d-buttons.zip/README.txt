A Pen created at CodePen.io. You can find this one at https://codepen.io/impressivewebs/pen/GzqId.

 A more accessible version of the demo found here: 
http://css-tricks.com/circular-3d-buttons/

Accessiblity HTML for the font icons from here:
http://css-tricks.com/html-for-icon-font-usage/
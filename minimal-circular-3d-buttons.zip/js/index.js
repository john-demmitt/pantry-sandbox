/*
From this article:
https://css-tricks.com/circular-3d-buttons/
*/
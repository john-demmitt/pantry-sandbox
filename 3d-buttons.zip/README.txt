A Pen created at CodePen.io. You can find this one at https://codepen.io/john-demmitt/pen/MEWZqj.

 Experiment creating 3d buttons using only CSS